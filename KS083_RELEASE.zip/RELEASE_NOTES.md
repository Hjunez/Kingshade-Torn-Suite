# Kingshade Suite 0.8.3 Beta

Faction-tested synchronized release of Scout and War Tools.

## Highlights

- Exact Hospital, Jail and Federal countdowns when Torn exposes an end timestamp
- Marked travel ETA estimates where exact arrival data is unavailable
- READY, EASY NOW, SOON and NO DATA filtering
- Shared status data between Scout and War Tools
- Reduced mobile scrolling overhead
- Version-mismatch warnings and automated repository validation

Bootlegging Clean 4.1.1 remains a standalone component.

This is a prerelease intended for faction testing.
