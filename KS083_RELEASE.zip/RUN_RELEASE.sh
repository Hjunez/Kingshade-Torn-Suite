#!/usr/bin/env bash
set -euo pipefail

REPO="Hjunez/Kingshade-Torn-Suite"
SOURCE_BRANCH="test-status-timers"
RELEASE_BRANCH="release/v0.8.3-beta"
VERSION="0.8.3"
TAG="v0.8.3-beta.1"
AUTO_MERGE=0

for arg in "$@"; do
  case "$arg" in
    --auto-merge) AUTO_MERGE=1 ;;
    --help|-h)
      cat <<'EOF'
Usage: bash RUN_RELEASE.sh [--auto-merge]

Without --auto-merge, the script creates/pushes the release branch and PR,
then asks for confirmation before merging.
EOF
      exit 0
      ;;
    *) printf 'Unknown option: %s\n' "$arg" >&2; exit 2 ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"
WORKDIR="$HOME/kingshade-release-work"

say() { printf '\n==> %s\n' "$*"; }
warn() { printf '\nWARNING: %s\n' "$*" >&2; }
die() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

[[ -d "$PAYLOAD" ]] || die "Package payload is missing."

if command -v pkg >/dev/null 2>&1; then
  say "Installing required Termux packages"
  pkg install -y git gh
fi

command -v git >/dev/null 2>&1 || die "git is not installed."
command -v gh >/dev/null 2>&1 || die "GitHub CLI (gh) is not installed."

if ! gh auth status -h github.com >/dev/null 2>&1; then
  say "GitHub login is required. Complete the browser/device-code login."
  gh auth login -h github.com -p https -w
fi

LOGIN="$(gh api user --jq .login)"
[[ "$LOGIN" == "Hjunez" ]] || warn "Authenticated as $LOGIN, expected Hjunez. Continuing only if this account can write to $REPO."

if ! git config --global user.name >/dev/null 2>&1; then
  git config --global user.name "$LOGIN"
fi
if ! git config --global user.email >/dev/null 2>&1; then
  USER_ID="$(gh api user --jq .id)"
  git config --global user.email "${USER_ID}+${LOGIN}@users.noreply.github.com"
fi

if [[ -e "$WORKDIR" ]]; then
  BACKUP="${WORKDIR}.backup-$(date +%Y%m%d-%H%M%S)"
  say "Moving previous workspace to $BACKUP"
  mv "$WORKDIR" "$BACKUP"
fi

say "Cloning $REPO"
gh repo clone "$REPO" "$WORKDIR"
cd "$WORKDIR"
git fetch origin --prune

git show-ref --verify --quiet "refs/remotes/origin/$SOURCE_BRANCH" \
  || die "Remote source branch origin/$SOURCE_BRANCH does not exist."

say "Creating clean release branch from $SOURCE_BRANCH"
git checkout -B "$RELEASE_BRANCH" "origin/$SOURCE_BRANCH"

say "Applying tested scripts and professional repository files"
cp -R "$PAYLOAD"/. .

# Remove temporary or obsolete root files.
rm -f TEST_NOTES_v*.txt
rm -f KS_Status_Diagnostics*.user.js
rm -f ./*.zip
rm -f CHECKSUMS* SHA256SUMS* UPLOAD_INSTRUCTIONS*
rm -f Kingshade_Scout_Torn_PDA_v0.7.0_FINAL.user.js
rm -f KS_War_Tools_Torn_PDA.user.js

# Keep exactly one current Scout and War Tools file.
shopt -s nullglob
SCOUT="Kingshade_Scout_Torn_PDA_v${VERSION}.user.js"
WAR="KS_War_Tools_Torn_PDA_v${VERSION}.user.js"
for file in Kingshade_Scout_Torn_PDA*.user.js; do
  [[ "$file" == "$SCOUT" ]] || rm -f "$file"
done
for file in KS_War_Tools_Torn_PDA*.user.js; do
  [[ "$file" == "$WAR" ]] || rm -f "$file"
done

say "Running local validation"
bash tools/validate-suite.sh

git add -A
if git diff --cached --quiet; then
  say "No new file changes were needed on the release branch"
else
  git commit -m "release: prepare Kingshade Suite v${VERSION} beta"
fi

say "Pushing $RELEASE_BRANCH"
git push --force-with-lease -u origin "$RELEASE_BRANCH"

PR_NUMBER="$(gh pr list --repo "$REPO" --head "$RELEASE_BRANCH" --base main --state open --json number --jq '.[0].number // empty')"
if [[ -z "$PR_NUMBER" ]]; then
  say "Creating pull request into main"
  PR_URL="$(gh pr create \
    --repo "$REPO" \
    --base main \
    --head "$RELEASE_BRANCH" \
    --title "Release Kingshade Suite v${VERSION} Beta" \
    --body-file "$SCRIPT_DIR/PR_BODY.md")"
  PR_NUMBER="$(gh pr view "$PR_URL" --repo "$REPO" --json number --jq .number)"
else
  PR_URL="$(gh pr view "$PR_NUMBER" --repo "$REPO" --json url --jq .url)"
  say "Using existing pull request #$PR_NUMBER"
fi

say "Pull request ready: $PR_URL"
gh pr view "$PR_NUMBER" --repo "$REPO"

if [[ "$AUTO_MERGE" -eq 0 ]]; then
  printf '\nType MERGE to squash-merge PR #%s into main, or press Enter to stop here: ' "$PR_NUMBER"
  read -r CONFIRM
  if [[ "$CONFIRM" != "MERGE" ]]; then
    say "Stopped safely. The pull request remains open."
    exit 0
  fi
fi

say "Squash-merging pull request into main"
gh pr merge "$PR_NUMBER" --repo "$REPO" --squash --delete-branch=false

say "Refreshing main"
git checkout main
git pull --ff-only origin main

say "Ensuring dev branch exists"
if git ls-remote --exit-code --heads origin dev >/dev/null 2>&1; then
  say "dev already exists; leaving it unchanged"
else
  git branch dev origin/main
  git push -u origin dev
fi

say "Updating repository description and topics"
gh repo edit "$REPO" \
  --description "Read-only Torn PDA userscripts for faction intelligence, war filtering and crime guidance." \
  --add-topic torn-city \
  --add-topic torn-pda \
  --add-topic userscript \
  --add-topic javascript \
  >/dev/null 2>&1 || warn "Repository topics/description could not be updated; release work is still complete."

say "Creating GitHub prerelease if it does not already exist"
if gh release view "$TAG" --repo "$REPO" >/dev/null 2>&1; then
  say "Release $TAG already exists; leaving it unchanged"
else
  gh release create "$TAG" \
    "$SCOUT" \
    "$WAR" \
    --repo "$REPO" \
    --target main \
    --prerelease \
    --title "Kingshade Suite ${VERSION} Beta" \
    --notes-file "$SCRIPT_DIR/RELEASE_NOTES.md"
fi

say "Final validation on main"
bash tools/validate-suite.sh

cat <<EOF

DONE

Repository: https://github.com/$REPO
Merged PR:  $PR_URL
Main:       updated to Kingshade Suite $VERSION Beta
Dev branch: created if it did not already exist
Test branch: $SOURCE_BRANCH retained
Release:    $TAG created or preserved
EOF
