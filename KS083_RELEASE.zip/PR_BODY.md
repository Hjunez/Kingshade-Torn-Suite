## Kingshade Suite 0.8.3 Beta

Promotes the synchronized and faction-tested Scout and War Tools pair to `main`.

### Included

- Scout 0.8.3
- War Tools 0.8.3
- Exact Hospital, Jail and Federal timers
- Marked travel ETA estimates
- Shared Scout/War status data
- Mobile UI and scrolling optimizations
- Synchronized version validation
- Cleaned temporary diagnostics and test notes
- Updated README and CHANGELOG
- Automated GitHub Actions validation
- Release and contribution templates

### Safety

The scripts remain informational and visual. They do not automate Torn actions.
