KINGSHade SUITE 0.8.3 — RELEASE AUTOMATION
===========================================

RECOMMENDED: TERMUX
-------------------

1. Download this ZIP to the Android Download folder.
2. Open Termux.
3. The first time only, run:

   termux-setup-storage

   Approve Android's storage permission.

4. Copy and run this single command:

   pkg install -y unzip && rm -rf ~/ks-release && mkdir -p ~/ks-release && unzip -o /sdcard/Download/Kingshade_Suite_v0.8.3_RELEASE_AUTOMATION.zip -d ~/ks-release && bash ~/ks-release/RUN_RELEASE.sh --auto-merge

The script installs Git and GitHub CLI if required. If GitHub CLI is not logged in,
it displays a device code/browser login. Complete that once, then the script continues.

The --auto-merge option performs the complete release:
- creates release/v0.8.3-beta from test-status-timers
- updates and cleans the repository
- validates versions and file layout
- pushes the release branch
- creates a Pull Request to main
- squash-merges it
- keeps test-status-timers
- creates dev if missing
- creates GitHub prerelease v0.8.3-beta.1

SAFER INTERACTIVE MODE
----------------------

Replace the end of the command with:

   bash ~/ks-release/RUN_RELEASE.sh

The script then creates the branch and Pull Request, shows the result, and waits for
you to type MERGE before changing main.

GITHUB CODESPACES
-----------------

1. Open the repository on github.com.
2. Code > Codespaces > Create codespace.
3. Upload this ZIP into the Codespace file explorer.
4. Run:

   rm -rf /tmp/ks-release && mkdir -p /tmp/ks-release && unzip -o Kingshade_Suite_v0.8.3_RELEASE_AUTOMATION.zip -d /tmp/ks-release && bash /tmp/ks-release/RUN_RELEASE.sh --auto-merge

WHAT THE PACKAGE CHANGES
------------------------

- Scout and War Tools are synchronized at 0.8.3.
- Old script copies, test notes and diagnostics are removed.
- README and CHANGELOG are replaced with release-ready versions.
- VERSION is added as the source of truth.
- dev and release workflow documentation are added.
- GitHub Actions automatically validates future changes.
- Pull Request and bug-report templates are added.
- Bootlegging Clean 4.1.1 remains standalone and unchanged.

The script never asks for or stores a Torn API key.
